<?php

namespace App\Repositories\Api\Register;


interface RegisterRepositoryInterface
{
    public function register($request);
}

