<?php

namespace App\Repositories\Api\Login;


interface LoginRepositoryInterface
{
    public function login($request);
}

